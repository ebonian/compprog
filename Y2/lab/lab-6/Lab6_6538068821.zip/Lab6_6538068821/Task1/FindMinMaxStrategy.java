public interface FindMinMaxStrategy {
    public int findMin(int[] array);

    public int findMax(int[] array);
}
